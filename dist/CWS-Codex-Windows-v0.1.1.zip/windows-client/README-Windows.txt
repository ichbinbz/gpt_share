﻿CWS Codex Windows 员工端
========================

系统要求：
- Windows 10 或 Windows 11
- Visual Studio Code
- 能访问公司内网代理 192.168.2.38:7897，或已配置其他 HTTP/Mixed 代理
- 管理员从服务器签发、专门分配给本机的 CWS 设备令牌

安装：
1. 推荐直接双击 Release 中的图形安装程序“CWS-Codex-Setup-v0.1.1.exe”，不需要手工解压。
2. 使用管理员排障 ZIP 时，应先解压整个 ZIP，再双击“安装.cmd”或“Install.cmd”。不需要管理员权限。
3. 首次输入管理员从服务器签发的本机专用设备令牌。
4. 安装完成后，双击桌面的“公司 Codex（VS Code）”。
5. 安装器会创建隐藏的登录自启动后台任务；不需要保留 CMD 窗口。

网络切换：
- 默认：公司内网代理 http://192.168.2.38:7897
- Shadowrocket：http://127.0.0.1:1082
- 双击安装目录中的 Configure-Proxy.cmd 可随时修改。

注意：
- “公司 Codex（VS Code）”会启动 VS Code，并使用独立用户目录，可以与普通 VS Code 同时运行。
- 设备令牌通过 Windows DPAPI 加密，仅当前 Windows 用户可以解密。
- ChatGPT 短期访问令牌存放在 %USERPROFILE%\.cws-codex，并限制当前用户访问。
- Codex 继续使用官方 OpenAI Provider；本工具不配置自定义 Provider。
- 同一枚设备令牌不要分发给多台电脑；换机、遗失或离职时由管理员在服务器吊销。
- 后台任务每 5 分钟同步短期凭据，并按设备令牌上报本机 Codex 会话的累计 Token 数。
- 每次同步和上报还会记录本机默认网络的局域网 IPv4；该地址只用于公司内部设备追踪，不参与鉴权。
- 上报内容只有散列后的会话 ID 和 Token 计数，不上传对话、提示词、代码或文件内容。
- 统计用于公司内部用量分析，不等同于 OpenAI 官方账单或 Plus 剩余额度。
- 如果双击后无法使用，请运行安装目录中的“诊断.cmd”，它不会显示设备令牌明文。
